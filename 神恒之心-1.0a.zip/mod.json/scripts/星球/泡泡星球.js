const lib = require("base/lib");
const TBLY = new Planet("泡泡星球", Planets.sun, 1, 3.3);
TBLY.meshLoader = prov(() => new MultiMesh(
	new HexMesh(TBLY, 8)
));
TBLY.cloudMeshLoader = prov(() => new MultiMesh(
	new HexSkyMesh(TBLY, 2, 0.15, 0.14, 5, Color.valueOf("ffc4ffde"), 2, 0.42, 1, 0.43),
	new HexSkyMesh(TBLY, 3, 0.6, 0.15, 5, Color.valueOf("ff349988"), 2, 0.42, 1.2, 0.45)
));
TBLY.generator = new SerpuloPlanetGenerator();
TBLY.visible = TBLY.accessible = TBLY.alwaysUnlocked = TBLY.clearSectorOnLose = true;//可见 潮汐锁定 在行星菜单内显示 总是解锁 重置战败区块
TBLY.tidalLock = false;
TBLY.localizedName = "泡泡星球";
TBLY.bloom = false;
TBLY.startSector = 1;
TBLY.orbitRadius = 35;
TBLY.orbitTime = 180 * 60;
TBLY.rotateTime = 90 * 60;
TBLY.atmosphereRadIn = 0.02;
TBLY.atmosphereRadOut = 0.3;
TBLY.atmosphereColor = TBLY.lightColor = Color.valueOf("00FFE1BE");
TBLY.hiddenItems.addAll(Items.erekirItems).removeAll(Items.serpuloItems);
//泡泡星球.generator = new CPG;

const 资源共享地区 = new SectorPreset("资源共享地区", TBLY, 1);
资源共享地区.description = "泡泡星球的资源共享,后面特别困难";
资源共享地区.difficulty = 2;
资源共享地区.alwaysUnlocked = false;
资源共享地区.addStartingItems = true;
资源共享地区.captureWave = 0;
资源共享地区.localizedName = "资源共享地区";
exports.资源共享地区 = 资源共享地区;
lib.addToResearch(资源共享地区, {
	parent: "planetaryTerminal",
	objectives: Seq.with(
		new Objectives.SectorComplete(SectorPresets.planetaryTerminal))
});

/*const 资源共享地区-G = new SectorPreset("资源共享地区-G", TBLY, 101);
资源共享地区-G.description = "泡泡星球的资源共享,后面特别困难";
资源共享地区-G.difficulty = 1;
资源共享地区-G.alwaysUnlocked = false;
资源共享地区-G.addStartingItems = true;
资源共享地区-G.captureWave = 0;
资源共享地区-G.localizedName = "资源共享地区-G";
exports.资源共享地区-G = 资源共享地区-G;
lib.addToResearch(资源共享地区-G, {
	parent: "资源共享地区",
	objectives: Seq.with(
		new Objectives.SectorComplete(SectorPresets.planetaryTerminal))
});*/
