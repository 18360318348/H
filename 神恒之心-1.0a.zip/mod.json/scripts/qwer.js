
Events.on(EventType.ClientLoadEvent, cons(e => {
    var dialog = new BaseDialog("[red]神恒之心信息栏");
    dialog.cont.image(Core.atlas.find("神恒之心-神恒之心")).row();;
    dialog.buttons.defaults().size(210, 64);
    dialog.buttons.button("@close", run(() => {
        dialog.hide();
    })).size(210, 64);
    dialog.cont.pane((() => {
        var table = new Table();   
         table.add("[red]—————特别感谢—————\n[yellow]晚安(励志gansi白猫)带来这些贴图\n[blue]—————联系方式—————\n[white]神恒之心模组群(摸鱼) : 730570292 (1H3Y)").left().growX().wrap().width(600).maxWidth(1000).pad(4).labelAlign(Align.left);
        table.row();
        
table.button("[red]BOSS兵类", run(() => {
    var dialog2 = new BaseDialog("[red]BOSS兵类[cyan]信息");
    var table = new Table();
    dialog2.cont.image(Core.atlas.find("神恒之心-帝神-极森-LOGO")).row();;
    dialog2.buttons.defaults().size(1, 50);
    
    var t = new Table();
    t.add("[red]BOSS兵类名字:[cyan]帝神-极森\n[green]生命值:[red]900000\n[green]护甲值:[red]400\n[green]攻击特别强大,话说它有自己技能可以让加速,而且还可以生产原版兵类,打败它必须要多加修复器和攻击伤害高的炮塔,也可以其他mod联合").left().growX().wrap().width(600).maxWidth(1000).pad(4).labelAlign(Align.left);
        table.row();
    var table = new Table();
    dialog2.cont.image(Core.atlas.find("神恒之心-帝神-狐幽-LOGO")).row();;
    dialog2.buttons.defaults().size(1, 50);
    
    var t = new Table();
    t.add("[red]BOSS兵类名字:[cyan]帝神-狐幽\n[green]生命值:[red]4800000\n[green]护甲值:[red]1050\n[green]攻击特别强大,,它可以生产mod兵类,打败它必须要多加修复器,塑钢墙，血量高墙，防子弹炮和攻击伤害高的炮塔,也可以其他mod联合").left().growX().wrap().width(600).maxWidth(1000).pad(4).labelAlign(Align.left);
        table.row();
    var table = new Table();
    dialog2.cont.image(Core.atlas.find("神恒之心-帝神-龙椹-LOGO")).row();;
    dialog2.buttons.defaults().size(1, 50);
    
    var t = new Table();
    t.add("[red]BOSS兵类名字:[cyan]帝神-龙椹\n[green]生命值:[red]12900000\n[green]护甲值:[red]1020\n[green]攻击些强大,它技能可以帮助兵类恢复血量,打败它必须要多加修复器,塑钢墙，血量高墙，防子弹炮和攻击伤害高的炮塔,也可以其他mod联合").left().growX().wrap().width(600).maxWidth(1000).pad(4).labelAlign(Align.left);
        table.row();
    var table = new Table();
    dialog2.cont.image(Core.atlas.find("神恒之心-帝神-蜘莱-LOGO")).row();;
    dialog2.buttons.defaults().size(1, 50);
    
    var t = new Table();
    t.add("ERROR").left().growX().wrap().width(600).maxWidth(1000).pad(4).labelAlign(Align.left);
        table.row();
    dialog2.buttons.button("@close", run(() => {
        dialog2.hide();
    })).size(210, 50);
       dialog2.show();
    })).size(210, 50).row();
    
table.button("[red]更新日志", run(() => {
    var dialog2 = new BaseDialog("[red]更新日志");
    var table = new Table();
	
	var t = new Table();
	t.add("[red]各位，我深重的告诉你们，我本来贴图师帮助创世神和高科技的贴图，但下周会来学习，初二马上来了。很抱歉，我已尽力用实力画贴图花纹、配色、凹凸、适合等条件\n刚刚投票结束了，看到了我觉得《花杨永瀛の痛》，为什么不画贴图?原因学业可能马上来了，没办法给你们合适做贴图条件，但我尽力的做贴图帮忙\n有时可能不更贴图，或许每天更了较多贴图。唉，时流很快\n如果想要贴图的话，那就去找贴图师或者是我\n抱歉\n[grey]----------来自群里你的群友贴图师花杨永瀛\n[white]——————[未完成版本]2022.8.20 :\n——[red]更新 :\n[pink]1.[green]优化工厂贴图\n[white]——————[未完成版本]2022.8.18 :\n——[red]更新 :\n[pink]1.[green]增加了两个分别绿墨钻头和扫温泵\n[white]——————2022.8.17 :\n[yellow]模组未完成\n[white]——[red]问题 :\n[pink]1.[green]炮塔底座未完善\n[pink]2.[green]平衡不太合理,但自己习惯了");
    dialog2.cont.add(new ScrollPane(t)).size(500, 600).row();
    dialog2.buttons.defaults().size(620, 64);
    dialog2.buttons.button("@close", run(() => {
        dialog2.hide();
    })).size(500, 64);
       dialog2.show();
    })).size(210, 64);
        return table;
    })()).grow().center().maxWidth(600);
    dialog.show();
}));