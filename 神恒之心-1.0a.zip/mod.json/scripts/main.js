importPackage(Packages.mindustry.graphics)

Events.on(EventType.ClientLoadEvent, () => {
const loadren = extend(MenuRenderer, {
    render(){
        Draw.rect(Core.atlas.find("神恒之心-神之浩眼"), Core.graphics.getWidth() / 2, Core.graphics.getHeight() / 2, 2000, 1200);
    }
})

function Class(id) {
	return Seq([id]).get(0)
}

var fi = Class(MenuFragment).getDeclaredField("renderer");
fi.setAccessible(true);
fi.set(Vars.ui.menufrag, loadren);
})

MapResizeDialog.minSize = 0
MapResizeDialog.maxSize = 50000
require("星球/泡泡星球");
//require("星球/莱普德科");
require('qwer');
require('辅助/核心资源显示');