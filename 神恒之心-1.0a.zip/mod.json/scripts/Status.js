
var effectL = new StatusEffect("护盾增益");
effectL.color = Color.valueOf("ffffff");
effectL.damage = 1850
effectL.reloadMultiplier = 2.5;//射击速度
//effectL.effect = FxL;
effectL.effect = Fx.bubble;
exports.effectL=effectL

/*XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
*/